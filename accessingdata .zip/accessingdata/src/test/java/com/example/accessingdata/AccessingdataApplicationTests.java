package com.example.accessingdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
