package com.example.accessingdata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Эндпоинт для запроса студентов по имени
    @GetMapping("/query")
    public List<Map<String, Object>> queryByFirstName(@RequestParam String firstName) {
        return jdbcTemplate.queryForList(
                "SELECT * FROM Students WHERE FirstName = ?", firstName);
    }

}