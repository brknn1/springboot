package com.example.accessingdata;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

@SpringBootApplication
public class AccessingdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccessingdataApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(JdbcTemplate jdbcTemplate) {
		return args -> {
			// create table  Students
			jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS Students (" +
					"Id SERIAL, FirstName VARCHAR(255), LastName VARCHAR(255), StudentId VARCHAR(255))");

			// Добавляем 2 записи
			jdbcTemplate.update("INSERT INTO Students (FirstName, LastName) VALUES (?, ?)", "August", "Bell");
			jdbcTemplate.update("INSERT INTO Students (FirstName, StudentId) VALUES (?, ?)", "Jane", "12345");

			// request for "August"
			String firstNameQuery = "August";
			List<Map<String, Object>> firstname = jdbcTemplate.queryForList(
					"SELECT * FROM Students WHERE FirstName = ?", firstNameQuery);



			String lastNameQuery = "Bell";
			List<Map<String, Object>> lastname = jdbcTemplate.queryForList(
					"SELECT * FROM Students WHERE LastName = ?", lastNameQuery);

			String 	StudentIdQuery = "12345";
			List<Map<String, Object>> studentId = jdbcTemplate.queryForList(
					"SELECT * FROM Students WHERE StudentId = ?", StudentIdQuery);



			//results in console
			System.out.println("Wyniki zapytania dla FirstName: = " + firstNameQuery + ":");
			firstname.forEach(record -> System.out.println(firstname));

			System.out.println("Wyniki zapytania dla LastName: = " + lastNameQuery + ":");


			System.out.println("Wyniki zapytania dla Student ID: = " + StudentIdQuery + ":");



		};
	}
}
